
public class Pacientes {

    private String dni;
    private String nombre;
    private String fNacimiento;
    private String aseguradora;

    public Pacientes() {
        super();
    }
    
    public String getdni() {
        return dni;
    }
    public void setdni(String dni) {
        this.dni = dni;
    }
    public String getnombre() {
        return nombre;
    }
    public void setnombre(String nombre) {
        this.nombre = nombre;
    }
    public String getfNacimiento() {
        return fNacimiento;
    }
    public void setfNacimiento(String fNacimiento) {
        this.fNacimiento = fNacimiento;
    }
    public String getaseguradora() {
        return aseguradora;
    }
    public void setaseguradora(String aseguradora) {
        this.aseguradora = aseguradora;
    }
}
